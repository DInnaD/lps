<div class="form-group">
	{!!Form::label('name', 'Name') !!}	
    {!!Form::text('name', null, ['class' => 'form-control']) !!}
    {!!Form::label('link', 'Link') !!}
    {!!Form::text('link', null, ['class' => 'form-control']) !!} 
    {!!Form::label('callBack', 'Icon') !!}
    {!!Form::text('callBack', null, ['class' => 'form-control']) !!}    
    
</div>

