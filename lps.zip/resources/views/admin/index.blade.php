@extends('layouts.admin')

@section('header')
	@include('admin.header')
@endsection

