

<div class="header_box" style="
    height: 100px;
">
<div class=" delay-01s animated fadeInDown wow animated">

 <a href="{{ url ('/') }}">{!! Html::image('assets/img/'.$page->images,'',['class' => 'zoomIn wow animated']) !!}</a>
 </div>
</div> 
     




     
