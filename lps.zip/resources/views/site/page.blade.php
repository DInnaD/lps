@extends('layouts.site_portfolio')



@section('content')
	@include('site.content_page')
@endsection