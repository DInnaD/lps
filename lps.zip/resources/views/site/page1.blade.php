@extends('layouts.site_page')


@section('content_page1')
	@include('site.content_page1')
@endsection
