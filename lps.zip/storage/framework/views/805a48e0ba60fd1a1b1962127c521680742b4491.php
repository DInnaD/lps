    
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-md-offset-0">
                <div class="panel panel-default">
               
                    <div class="panel-heading">Portfolios</div>

                    <div class="panel-body">
                        <a class="btn btn-info btn-xs col-md-1 col-sm-2 col-xs-2" href="<?php echo e(route('portfolios.index')); ?>">
                    <i class="fa fa-backward" aria-hidden="true"></i> back
                    </a>
                       ||<?php echo e(link_to_route('portfolios.index', 'portfolio', null, ['class' => 'btn btn-info btn-xs'])); ?>

                       <?php echo e(link_to_route('admin', 'admin', null, ['class' => 'btn btn-info btn-xs'])); ?>

                        <?php echo e(link_to_route('portfolioAlls.create', 'create', [$portfolio->id, $page->id], ['class' => 'btn btn-info btn-xs'])); ?>


                        <hr>
                        <table class="table table-bordered table-responsive table-striped">
                            <tr>
                            
                                <th width="5%">id</th>
                                <th width="20%">Name</th>
                                <th width="15%">Filter</th>
                                <th width="35%">Link</th>
                                <th width="5%">Images</th>                                
                                <th width="25%">Actions</th>
                            </tr>
                            <tr>
                            
                                <td colspan="6" class="light-green-background no-padding" title="Create new template">
                                    <div class="row centered-child">
                                        <div class="col-md-12">

                                        </div>
                                    </div>
                                </td>
                            </tr>
                        
                        
                        <?php $__currentLoopData = $page->portfolioAlls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolioAll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                             
                                <td><?php echo e($portfolioAll->id); ?></td>
                                <td><?php echo e($portfolioAll->name); ?></td>
                                <td><?php echo e($portfolioAll->filter); ?></td>
                                <td><?php echo e($portfolioAll->link); ?></td>       
                                <td><?php echo e($portfolioAll->images); ?></td>
                                
                                
                                <!--??????????????????????????_templates-->
                                <td>
                                     <?php echo e(Form::open(['route' => array_merge(['portfolioAlls.destroy', $portfolioAll->id], compact('portfolio', 'page')), 'class' => 'confirm-delete','method' => 'DELETE'])); ?>

                                     
                                     <?php echo e(Form::button('Delete', ['class' => 'btn btn-danger btn-xs', 'type' => 'submit'])); ?>

                                    <?php echo e(Form::close()); ?>

                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                        <div class="text-center">
                            { !! $portfolioAlls->render() !!}

                        </div>
                   
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.header_all', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>