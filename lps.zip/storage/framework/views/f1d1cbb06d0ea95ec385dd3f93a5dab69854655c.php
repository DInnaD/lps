<div class="form-group">
	   
    
    <?php echo Form::label('old_images', 'Image'); ?>	
    <?php echo Html::image('assets/img/'.$portfolio['images']); ?>

    <?php echo Form::hidden('old_images', $portfolio['images'], ['class' => 'form-control', 'filestyle', 'data-buttonText'=>'Chose image']); ?>

    	
    
</div>

