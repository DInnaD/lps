<div class="form-group">
	<?php echo Form::label('name', 'Name'); ?>	
    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

    <?php echo Form::label('text', 'Content'); ?>

    <?php echo Form::textarea('text', null, ['class' => 'form-control class' ]); ?>


    <?php echo Form::label('icon', 'Icon'); ?>

    <?php echo Form::text('icon', null, ['class' => 'form-control']); ?>

</div>

