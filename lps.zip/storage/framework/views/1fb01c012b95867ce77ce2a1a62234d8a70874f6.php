<h1><?php echo e($data['name']); ?></h1>
<div><?php echo e($data['text']); ?></div>
