<div class="form-group">
	
    
    <?php echo Form::label('old_images', 'Words'); ?>	
    <?php echo Html::image('assets/img/'.$page['images']); ?>

    <?php echo Form::hidden('old_images', $page['images'], ['file'=>'true','class' => 'form-control', 'filestyle', 'data-buttonText'=>'Chose Immage', 'enctype'=>'multipart/form-data']); ?>

    
    	
    
    	
    
</div>

