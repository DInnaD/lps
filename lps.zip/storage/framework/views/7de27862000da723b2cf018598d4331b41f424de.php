<?php $__env->startSection('content_portfolio'); ?>



<div class="container">
 <div class="flex-center position-ref full-height">



            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <ul class="social_links">
                    <?php if(auth()->guard()->check()): ?>
                        
                        

                        <li class="pinterest animated bounceIn wow delay-01s"><a href="<?php echo e(url('/admin')); ?> "><i class="fa fa-sign-in " style="color:green"></i></a></li>
                        
                        <li class="pinterest animated bounceIn wow delay-02s">
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <i class="fa fa-sign-out " style="color:red"></i>
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                  
                    <?php if(isset($socialAlls) && is_object($socialAlls)): ?>
                    <?php $__currentLoopData = $page->socialAlls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialAll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>             
                                    
                        <li class="gplus animated bounceIn wow delay-02s" target="_blank"><a href="<?php echo e($socialAll->link); ?>" target="_blank"><i class="fa <?php echo e($socialAll->callBack); ?>"></i></a></li>

                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php else: ?>
                        
                       
                        <li class="pinterest animated bounceIn wow delay-01s"><a href=" <?php echo e(route('login')); ?> "><i class="fa fa-sign-in " style="color:green"></i></a></li>
                        <li class="twitter animated bounceIn wow delay-02s"><a href="<?php echo e(route('register')); ?> "><i class="far fa-registerd" ></i></a></li>

                    <?php if(isset($socialAlls) && is_object($socialAlls)): ?>
                    <?php $__currentLoopData = $page->socialAlls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialAll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                         
                    

                        <li class="gplus animated bounceIn wow delay-02s" target="_blank"><a href="<?php echo e($socialAll->link); ?>" target="_blank"><i class="fa <?php echo e($socialAll->callBack); ?>"></i></a></li>
                        
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </ul>
                    
                    <?php endif; ?>
                </div>

            <?php endif; ?>
</div>
<div class=" delay-01s animated fadeInDown wow animated">

 <a href="<?php echo e(url ('/')); ?>"><?php echo Html::image('assets/img/'.$page->images,'',['class' => 'zoomIn wow animated']); ?></a>
 </div>

 </div>   
<!-- Portfolio -->
<section id="Portfolio" class="content"> 
  
  <!-- Container -->
  <div class="container portfolio_title"> 
    
    <!-- Title -->
    <div class="section-title">
   
    <h2><?php echo e($page->name); ?></h2>
    
    </div>

    <!--/Title --> 
    
  </div>
  <!-- Container -->
  
  <div class="portfolio-top"></div>
  
  <!-- Portfolio Filters tags  -->
  <div class="portfolio"> 
  
    <div id="filters" class="sixteen columns">
      <ul class="clearfix">
        <li><a id="all" href="#" data-filter="*" class="active">
          <h5>All</h5>
          </a></li>
          <?php $__currentLoopData = $tagMores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagMore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <li><a class="" href="" data-filter=".<?php echo e($tagMore); ?>">
          <h5><?php echo e($tagMore); ?></h5>
          </a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        
        
      </ul>
    </div>
    <!--/Portfolio Filters --> 
 
    <!-- Portfolio Wrapper -->
    <div class="isotope fadeInLeft animated wow" style="position: relative; overflow: hidden; height: 480px;" id="portfolio_wrapper"> 
       <?php $__currentLoopData = $page->portfolioAlls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <!-- Portfolio Item -->
      <div style="position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px) scale3d(1, 1, 1); width: 337px; opacity: 1;" class="portfolio-item one-four   <?php echo e($item->filter); ?> isotope-item">
        <div class="portfolio_img"> 
        <?php echo Html::image('assets/img/'.$item->images,$item->name); ?>

        </div>        
        <div class="item_overlay">
          <div class="item_info">
             
            <a class="" href="<?php echo e($item->link); ?>" target="_blank"><i class="fa fa-facebook" style = "font-size: 40px; padding-bottom: 0px; "></i></a>
            <h4 class="project_name" style = "padding-top: 0px;"><?php echo e($item->name); ?></h4>


          </div>
        </div>
        </div>
  
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

      <!--/Portfolio Item  -->
      
    </div>
    <!--/Portfolio Wrapper --> 
    
  </div>
  <!--/Portfolio Filters -->
  
  <div class="portfolio_btm"></div>
  
  
  <div id="project_container">
    <div class="clear"></div>
    <div id="project_data"></div>

   
  </div>
 
  
</section>
<!--client_logos-->
<?php if(isset($peopleAlls) && is_object($peopleAlls)): ?>
<section class="page_section team" id="team"><!--main-section team-start-->
  <div class="container">
    
   
    <div class="team_section clearfix">
    <?php $__currentLoopData = $peopleAlls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peopleAll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
      
      <div class="team_area">
        <div class="team_box wow fadeInDown delay-0<?php echo e(($peopleAll->id*3 + 3)); ?>s">
        
          <div class="team_box_shadow"><a href="javascript:void(0)"></a></div>
          <?php echo Html::image('assets/img/'.$peopleAll->images,$peopleAll->name); ?>

          
        </div>
        <h3 class="wow fadeInDown delay-0<?php echo e(($peopleAll->id*3 + 3)); ?>s"><?php echo e($peopleAll->name); ?></h3>
        <span class="wow fadeInDown delay-0<?php echo e(($peopleAll->id*3 + 3)); ?>s"><?php echo e($peopleAll->position); ?></span>
        <p class="wow fadeInDown delay-0<?php echo e(($peopleAll->id*3 + 3)); ?>s"><?php echo e($peopleAll->text); ?></p>
      </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?> 

    </div>      
  </div>
</section>
<!--Footer-->
<footer class="footer_wrapper" id="contact">


    <div class="footer_bottom"><span>Copyright © 2018,    Create by <a href="https://www.facebook.com/ITvolunteerInnaDanylevska">ITvolunteersFIRST</a>. </span> </div>


  </div>
</footer>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-1.11.0.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-scrolltofixed.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.nav.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.easing.1.3.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.isotope.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/wow.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>





        
          
        

