

<?php if(isset($pages) && is_object($pages)): ?>

<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($page->id%2 == 0 ): ?> 
     <!--Header_section--> 
<!--Hero_Section id=home-->
<section id="<?php echo e($page->alias); ?>" class="top_cont_outer">
  <div class="hero_wrapper">
    <div class="container">

      <div class="hero_section">
        <div class="row">
          <div class="col-lg-5 col-sm-7">
            <div class="top_left_cont zoomIn wow animated"> 
              <?php echo $page->text; ?>

              <a href="<?php echo e(route('page', array('alias' => $page->alias))); ?>" class="read_more2">Read more</a> </div>
          </div>
          <div class="col-lg-7 col-sm-5">
            <?php echo Html::image('assets/img/'.$page->images,'',['class' => 'zoomIn wow animated']); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--Hero_Section--> 
<?php else: ?> 

<section id="<?php echo e($page->alias); ?>"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><?php echo e($page->name); ?></h2>
    <div class="inner_section">
    <div class="row">
      <div class=" col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right">
      <?php echo Html::image('assets/img/'.$page->images,'',['class' => 'img-circle delay-03s zoomIn wow animated']); ?>

      </div>
        <div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
            <div class=" delay-01s animated fadeInDown wow animated">
            <?php echo $page->text; ?>

              
</div>
<div class="work_bottom"> <span>Want to know more..</span> <a href="<?php echo e(route('page', array('alias' => $page->alias))); ?>" class="contact_btn">Contact Us</a> </div>       
       </div>
        
      </div>
      
      
    </div>
  </div> 
  </div>
</section>
<!--Aboutus--> 

<?php endif; ?>

<?php if($page->id%2 == 0 ): ?> 
     <!--Header_section--> 
<!--Hero_Section id=home-->
<section id="<?php echo e($page->alias); ?>" class="top_cont_outer">
  <div class="hero_wrapper">
    <div class="container">

      <div class="hero_section">
        <div class="row">
          <div class="col-lg-5 col-sm-7">
            <div class="top_left_cont zoomIn wow animated"> 
              <?php echo $page->text; ?>

              <a href="<?php echo e(route('page', array('alias' => $page->alias))); ?>" class="read_more2">Read more</a> </div>
          </div>
          <div class="col-lg-7 col-sm-5">
            <?php echo Html::image('assets/img/'.$page->images,'',['class' => 'zoomIn wow animated']); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--Hero_Section--> 
<?php else: ?> 

<section id="<?php echo e($page->alias); ?>"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><?php echo e($page->name); ?></h2>
    <div class="inner_section">
    <div class="row">
      <div class=" col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right">
      <?php echo Html::image('assets/img/'.$page->images,'',['class' => 'img-circle delay-03s zoomIn wow animated']); ?>

      </div>
        <div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
            <div class=" delay-01s animated fadeInDown wow animated">
            <?php echo $page->text; ?>

              
</div>
<div class="work_bottom"> <span>Want to know more..</span> <a href="<?php echo e(route('page', array('alias' => $page->alias))); ?>" class="contact_btn">Contact Us</a> </div>       
       </div>
        
      </div>
      
      
    </div>
  </div> 
  </div>
</section>
<!--Aboutus--> 

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>
