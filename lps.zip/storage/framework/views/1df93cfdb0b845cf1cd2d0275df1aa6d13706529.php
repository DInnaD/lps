  <div class="container">
 
<div class="header_box">


         <script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>
     <div class=" scype animated bounceIn wow delay-02s" id="SkypeButton_Call_innadanylevska_1"><a href="javascript:void(0)">
 <script type="text/javascript">
 Skype.ui({
 "name": "chat",
 "element": "SkypeButton_Call_innadanylevska_1",
 "participants": ["innadanylevska"],
 "imageSize": 32
 });
 </script>
</a></div>
      
      <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <div id="main-nav" class="collapse navbar-collapse navStyle">
            <ul class="nav navbar-nav" id="mainNav">
              
            

            
            <li><a href="<?php echo e(url('/admin/portfolios')); ?>" class="scroll-link">LANDINGPAGES</a></li>
           
            
            <li><a href="<?php echo e(url('/admin/peoples')); ?>" class="scroll-link">PEOPLES</a></li>
            
            <li><a href="<?php echo e(url('/admin/services')); ?>" class="scroll-link"></a></li>
            <li><a href="<?php echo e(url('/admin/socials')); ?>" class="scroll-link"></a></li>
            <li><a href="<?php echo e(url('/admin/logos')); ?>" class="scroll-link"></a></li>
            
              
              
            </ul>
      </div>
     </nav>

      
      
    </div>
  </div>

<?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>