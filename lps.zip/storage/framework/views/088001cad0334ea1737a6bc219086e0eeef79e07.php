<div class="form-group">
	<?php echo Form::label('name', 'Name'); ?>	
    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

    <?php echo Form::label('alias', 'Alias'); ?>

    <?php echo Form::text('alias', null, ['class' => 'form-control']); ?>

    <?php echo Form::label('text', 'Content'); ?>

    <?php echo Form::textarea('text', null, ['class' => 'form-control class' ]); ?>

    <?php echo Form::label('link', 'Link'); ?>

    <?php echo Form::text('link', null, ['class' => 'form-control']); ?>

    <?php echo Form::label('images', 'Image'); ?>

    <?php echo Form::file('images', null, ['class' => 'form-control', 'style' => 'height:50px']); ?>

    


    
    
</div>

